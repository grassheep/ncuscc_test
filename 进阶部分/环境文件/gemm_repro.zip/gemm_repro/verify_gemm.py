# -*- coding: utf-8 -*-
"""
verify_gemm.py —— 在没有 GPU 的情况下验证 gemm_opt.cu 的正确性。

做法：把 CUDA kernel 的逻辑**逐字复刻**成 Python（含 shared memory 的装载/覆盖语义、
越界填 0、寄存器分块累加的**严格顺序**、写回的边界判断），再和一个朴素三重循环
参考实现逐元素对拍。

重点验证三件最容易出错的事：
  ① As 转置存储后下标 [k][m] 有没有搞错（转置错 = 全盘错）
  ② 尾块 / 不整除尺寸的填 0 与写回判断
  ③ K 方向分批搬运时，shared 被覆盖后有没有读到脏数据

因为累加顺序和 kernel 完全一致（k 从 0 到 K-1 依次累加），结果应当**逐位相同**。
"""

import math
import random
import sys

# ---- 与 gemm_opt.cu 中的宏保持完全一致 ----
BM, BN, BK = 64, 64, 16
TM, TN = 4, 4
THREADS_X = BN // TN                # 16
THREADS_Y = BM // TM                # 16
NTHREADS = THREADS_X * THREADS_Y    # 256
A_ELEMS = BM * BK                   # 1024
B_ELEMS = BK * BN                   # 1024
A_LOADS = A_ELEMS // NTHREADS       # 4
B_LOADS = B_ELEMS // NTHREADS       # 4


def kernel(A, B, M, K, N):
    """逐字复刻 gemm_tiled_kernel"""
    C = [0.0] * (M * N)
    grid_x = (N + BN - 1) // BN
    grid_y = (M + BM - 1) // BM
    numTiles = (K + BK - 1) // BK

    for by in range(grid_y):
        for bx in range(grid_x):
            # 一个 (by, bx) = 一个 block，自带 shared 与寄存器
            regs = {}
            for ty in range(THREADS_Y):
                for tx in range(THREADS_X):
                    regs[(ty, tx)] = [[0.0] * TN for _ in range(TM)]

            for t in range(numTiles):
                kBase = t * BK
                As = [[0.0] * BM for _ in range(BK)]   # As[k][m]（转置存放）
                Bs = [[0.0] * BN for _ in range(BK)]   # Bs[k][n]

                # ---------- 阶段 1：协作装载 ----------
                for ty in range(THREADS_Y):
                    for tx in range(THREADS_X):
                        tid = ty * THREADS_X + tx

                        for i in range(A_LOADS):
                            idx = tid + i * NTHREADS
                            m = idx // BK
                            k = idx % BK
                            gm = by * BM + m
                            gk = kBase + k
                            As[k][m] = A[gm * K + gk] if (gm < M and gk < K) else 0.0

                        for i in range(B_LOADS):
                            idx = tid + i * NTHREADS
                            k = idx // BN
                            n = idx % BN
                            gk = kBase + k
                            gn = bx * BN + n
                            Bs[k][n] = B[gk * N + gn] if (gk < K and gn < N) else 0.0

                # __syncthreads() ①

                # ---------- 阶段 2：寄存器分块累加 ----------
                for ty in range(THREADS_Y):
                    for tx in range(THREADS_X):
                        acc = regs[(ty, tx)]
                        for k in range(BK):
                            aReg = [As[k][ty * TM + i] for i in range(TM)]
                            bReg = [Bs[k][tx * TN + j] for j in range(TN)]
                            for i in range(TM):
                                for j in range(TN):
                                    acc[i][j] += aReg[i] * bReg[j]

                # __syncthreads() ②

            # ---------- 阶段 3：写回 ----------
            for ty in range(THREADS_Y):
                for tx in range(THREADS_X):
                    rowBase = by * BM + ty * TM
                    colBase = bx * BN + tx * TN
                    acc = regs[(ty, tx)]
                    for i in range(TM):
                        gr = rowBase + i
                        if gr < M:
                            for j in range(TN):
                                gc = colBase + j
                                if gc < N:
                                    C[gr * N + gc] = acc[i][j]
    return C


def reference(A, B, M, K, N):
    """朴素三重循环参考实现（行主序 C = A*B）"""
    C = [0.0] * (M * N)
    for r in range(M):
        for c in range(N):
            s = 0.0
            arow = r * K
            for t in range(K):
                s += A[arow + t] * B[t * N + c]
            C[r * N + c] = s
    return C


def check(got, exp):
    """题目误差规则 abs(a-e) <= 1e-3 + 1e-3*abs(e)，返回 (是否通过, 最大绝对误差, 占容差比例)"""
    maxabs = 0.0
    ratio = 0.0
    for a, e in zip(got, exp):
        if math.isnan(a) or math.isinf(a):
            return False, float("inf"), float("inf")
        d = abs(a - e)
        maxabs = max(maxabs, d)
        ratio = max(ratio, d / (1e-3 + 1e-3 * abs(e)))
    return ratio <= 1.0, maxabs, ratio


def run_case(M, K, N, seed=0):
    rng = random.Random(seed)
    A = [rng.uniform(-1.0, 1.0) for _ in range(M * K)]   # 输入值域 [-1,1]
    B = [rng.uniform(-1.0, 1.0) for _ in range(K * N)]
    got = kernel(A, B, M, K, N)
    exp = reference(A, B, M, K, N)
    ok, maxabs, ratio = check(got, exp)
    return ok, (got == exp), maxabs, ratio


def main():
    sizes = [
        (1, 1, 1), (2, 3, 4), (15, 16, 17), (16, 16, 16), (17, 15, 16),
        (31, 32, 33), (63, 64, 65), (64, 64, 64), (65, 63, 64),
        (1, 256, 1), (256, 1, 256), (1, 512, 1), (512, 1, 512),
        (127, 129, 131), (129, 65, 193), (255, 32, 64), (32, 255, 64),
        (511, 17, 33), (33, 511, 17), (255, 255, 16),
    ]

    print(f"{'M':>5}{'K':>5}{'N':>5}   {'误差判定':<10}{'逐位相同':<10}"
          f"{'最大绝对误差':>14}{'占容差比例':>12}")
    print("-" * 72)

    all_ok = True
    for (M, K, N) in sizes:
        ok, biteq, maxabs, ratio = run_case(M, K, N, seed=M * 7 + K * 13 + N)
        all_ok &= ok
        print(f"{M:>5}{K:>5}{N:>5}   {'PASS' if ok else 'FAIL':<10}"
              f"{'是' if biteq else '否':<10}{maxabs:>14.3e}{ratio:>12.3e}")
        sys.stdout.flush()

    # 随机尺寸（限制计算量：保证 M*K*N 不超过 30 万）
    rng = random.Random(2026)
    print("-" * 72)
    tot = 0
    passed = 0
    while tot < 60:
        M = rng.randint(1, 512)
        K = rng.randint(1, 512)
        N = rng.randint(1, 512)
        if M * K * N > 300000:
            continue
        ok, _, _, _ = run_case(M, K, N, seed=rng.randint(0, 10**6))
        tot += 1
        passed += ok
    print(f"随机尺寸 {tot} 例：{passed}/{tot} 通过")
    all_ok &= (passed == tot)

    print("=" * 72)
    print("总结论：", "全部通过，逻辑与边界处理正确 ✔" if all_ok else "存在失败用例 ✘")


if __name__ == "__main__":
    main()
