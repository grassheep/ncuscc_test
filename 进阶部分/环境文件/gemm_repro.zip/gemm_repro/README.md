# 6-1 GEMM 复现包

这一份是给复现者用的**最小可运行集**：一条命令，不需要改任何代码。目录里只有本关交付文件、自测程序、验证脚本和一份黄金输出。

## 一、最快复现

```bash
cd gemm_repro
bash run.sh
```

`run.sh` 会自动判断本机有什么，能做多少做多少：

| 本机条件 | 会做什么 | 结论强度 |
| --- | --- | --- |
| 只有 `python3` | CPU 逐字复刻 kernel 逻辑，80 组尺寸对拍，并与黄金输出逐字比对 | **能证明算法与边界正确** |
| `python3` + `nvcc` + NVIDIA GPU | 追加：编译、链接、`-Xptxas -v` 资源用量、16 组尺寸端到端 + 耗时 | 最完整 |
| 连 `python3` 都没有 | 打印环境信息，指出缺什么 | 无法下结论 |

退出码：`0` = 已做的检查全部通过；`1` = 有检查未通过。

## 二、文件清单

| 文件 | 作用 | 是否属于交付物 |
| --- | --- | --- |
| `gemm_opt.cu` | 6-1 的交付文件，入口 `extern "C" void solve(...)` | **是** |
| `test_gemm.cu` | 自测程序：与 CPU 参考结果对拍 + CUDA event 计时 | 否，仅供复现 |
| `verify_gemm.py` | 用 Python 逐字复刻 kernel 语义，无 GPU 也能验正确性 | 否，仅供复现 |
| `run.sh` | 一键复现脚本 | 否 |
| `expected_verify_output.txt` | `verify_gemm.py` 的黄金输出（80 组） | 否 |
| `MANIFEST.txt` | 四个文件的 SHA-256，`sha256sum -c` 可直接校验 | 否 |

`MANIFEST.txt` 的作用：确认拿到手的 `gemm_opt.cu` 就是被验证过的那一份，中间没有经过手工改动或转贴失真。

## 三、判据

### 3.1 逻辑正确性（CPU，必做）

`verify_gemm.py` 与黄金文件**逐字相同**即通过。它覆盖 20 组固定尺寸 + 60 组随机尺寸：

- 不整除 tile 的尾块：`17×15×16`、`63×64×65`、`127×129×131`、`511×17×33`
- 某维为 1 的极端形状：`1×256×1`、`512×1×512`
- 整数倍尺寸：`16³`、`64³`、`128³`、`256³`

关键看两列：**「误差判定」全是 PASS**、**「逐位相同」全是「是」**。逐位相同说明复刻的不是"另一个实现"，而是同一个执行过程。

### 3.2 端到端（有 GPU 时）

`test_gemm` 的判据与题面一致：

```text
|a − e| ≤ 1e-3 + 1e-3·|e|      （逐元素，占容差比例 ≤ 1.0 即合规）
```

期望看到 16 行 `PASS`，末尾一行 `512^3 占容差比例 = ...（<=1 即合规）`。

> 退出码 `2` 表示"本机没有显卡，跳过"，不是失败。无卡时 `cudaMalloc` / kernel 启动会静默失败，结果缓冲区保持全 0，直接算会得到一堆假 FAIL（占容差会挤在 400~1000 之间），所以程序在开头就做了 `cudaGetDeviceCount` 判断并提前返回。

## 四、环境要求

### 4.1 编译

| 项目 | 要求 |
| --- | --- |
| CUDA Toolkit | 任意版本均可（代码只用 `__shared__` / `__syncthreads()` / `<<<>>>` 等最基础特性） |
| 主机编译器 | gcc 即可；若 gcc 高于该 CUDA 的支持范围，`run.sh` 会自动加 `-allow-unsupported-compiler` |
| 显卡架构 | `run.sh` 用 `nvidia-smi --query-gpu=compute_cap` 自动探测；探测不到就不指定 `-arch`，由 nvcc 用默认架构 |

手工编译的命令（不跑脚本时）：

```bash
nvcc -O3 -o test_gemm test_gemm.cu gemm_opt.cu
./test_gemm
```

### 4.2 架构对照（手工指定 `-arch` 时用）

| 显卡 | `-arch` |
| --- | --- |
| GTX 10xx | `sm_61` |
| RTX 20xx / T4 | `sm_75` |
| RTX 30xx | `sm_86` |
| RTX 40xx | `sm_89` |
| RTX 50xx（Blackwell） | `sm_120`，**需 CUDA ≥ 12.8** |

不确定就写 `-arch=native`（CUDA 11.5+ 自动匹配本机显卡）。

### 4.3 依赖

`gemm_opt.cu` 只 `#include <cuda_runtime.h>`，不链接 cuBLAS / cuDNN / NPP，不用 Driver API，不用 C++17 及以上语法。所以**不需要额外装任何库**。

`verify_gemm.py` 只用 Python 标准库，不需要 numpy。

## 五、常见报错

| 报错 | 原因 | 处理 |
| --- | --- | --- |
| `unsupported GNU version` | gcc 高于 CUDA 支持范围 | 加 `-allow-unsupported-compiler`（`run.sh` 自动处理） |
| `nvcc fatal: Unsupported gpu architecture 'sm_120'` | CUDA < 12.8 遇到 Blackwell | 换 `-arch=native` 或升到 CUDA 12.8+ |
| `no CUDA-capable device is detected` | 本机无可用 GPU | 正常；改看第 1 项 CPU 对拍结果 |
| `undefined reference to solve(...)` | 编译命令漏了 `gemm_opt.cu` | `nvcc ... test_gemm.cu gemm_opt.cu` |
| `cuda_runtime.h: No such file` | 只装了驱动没装 Toolkit | 装 `cuda-toolkit`（或 `nvidia-cuda-dev`） |

## 六、两点说明

1、**性能数字以平台返回的 `performanceMedianUs` 为准。** 本包在本地跑出的耗时只用于横向比较（改与不改的差别），不作为成绩依据；不同显卡之间没有可比性。

2、**`test_gemm.cu` 与 `verify_gemm.py` 不提交。** 它们属于验证工具，本题交付物只有 `gemm_opt.cu` 与报告。
