#!/usr/bin/env bash
# =============================================================================
# run.sh —— 6-1 GEMM 复现脚本
#
# 用法：  bash run.sh
#
# 设计原则：**任何机器都能跑出结论**。
#   - 有 python3（几乎必然有）→ 跑 CPU 侧逻辑对拍，这是正确性的主要证据
#   - 有 nvcc + NVIDIA GPU     → 追加编译、链接、端到端 16 组尺寸与资源用量
#   - 两者都没有               → 至少把环境信息打出来，便于定位缺什么
#
# 退出码：0 = 已做的检查全部通过；1 = 有检查未通过
# =============================================================================
set -u
cd "$(dirname "$0")" || exit 1

ok=0
bad=0
pass() { echo "  [PASS] $*"; ok=$((ok + 1)); }
fail() { echo "  [FAIL] $*"; bad=$((bad + 1)); }

echo "============================================================"
echo " 6-1 GEMM 复现脚本"
echo " 目录：$(pwd)"
echo " 时间：$(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================================"
echo

# ---------------------------------------------------------------- 0. 环境 ---
echo "===== 0) 环境 ====="
uname -srm

HAS_PY=0
PY=""
if command -v python3 >/dev/null 2>&1; then
    HAS_PY=1
    PY=python3
elif command -v python >/dev/null 2>&1; then
    HAS_PY=1
    PY=python
fi
if [ "$HAS_PY" -eq 1 ]; then
    echo "python3 : $($PY -V 2>&1)"
else
    echo "python3 : 未安装"
fi

HAS_NVCC=0
if command -v nvcc >/dev/null 2>&1; then
    HAS_NVCC=1
    echo "nvcc    : $(nvcc --version 2>/dev/null | grep -o 'release [0-9.]*' | head -1)"
else
    echo "nvcc    : 未安装"
fi

HAS_GPU=0
if command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi >/dev/null 2>&1; then
    HAS_GPU=1
    echo "GPU     : $(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)"
    echo "驱动    : $(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1)"
else
    echo "GPU     : 无可用显卡（将跳过端到端，只做 CPU 逻辑验证）"
fi
echo

# ------------------------------------------------- 1. CPU 侧逻辑正确性 ------
echo "===== 1) 逻辑正确性（CPU 逐字复刻 kernel，任何机器都能跑）====="
if [ "$HAS_PY" -eq 0 ]; then
    fail "没有 python3，这一项跑不了；请先 apt install -y python3"
else
    raw=.verify.raw
    out=.verify.out
    "$PY" verify_gemm.py > "$raw" 2>&1
    rc=$?
    # 统一成 LF，避免 Windows / WSL 混合环境的行尾差异导致假 diff
    tr -d '\r' < "$raw" > "$out"
    tail -3 "$out" | sed 's/^/  /'
    if [ "$rc" -ne 0 ]; then
        fail "verify_gemm.py 退出码 $rc"
        sed -n '1,20p' "$out" | sed 's/^/    /'
    elif diff -q expected_verify_output.txt "$out" >/dev/null 2>&1; then
        pass "80 组尺寸全部通过，且输出与黄金文件逐字一致"
    elif grep -q "全部通过" "$out"; then
        pass "80 组尺寸全部通过（数字与黄金文件有细微差异，可能是 Python 版本不同）"
        diff expected_verify_output.txt "$out" | head -10 | sed 's/^/    /'
    else
        fail "对拍未通过，下面是差异（左=黄金，右=本次）"
        diff expected_verify_output.txt "$out" | head -20 | sed 's/^/    /'
    fi
    rm -f "$raw" "$out"
fi
echo

# --------------------------------------------- 2. 编译 / 端到端 ---------------
echo "===== 2) 编译与端到端（需要 nvcc + NVIDIA GPU）====="
if [ "$HAS_NVCC" -eq 0 ]; then
    echo "  跳过：没有 nvcc。安装方法见 环境与复现说明.md 第 4 节。"
    echo "  注：即使不装 CUDA，上面第 1 项已经能独立证明算法与边界处理正确。"
else
    ARCH=""
    if [ "$HAS_GPU" -eq 1 ]; then
        CAP=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1 | tr -d ' ')
        if [ -n "${CAP:-}" ]; then
            ARCH="-arch=sm_${CAP/./}"
            echo "  计算能力 ${CAP} -> ${ARCH}"
        fi
    fi

    EXTRA=""
    # shellcheck disable=SC2086
    try_build() {
        nvcc -O3 -std=c++14 $EXTRA $ARCH -o test_gemm test_gemm.cu gemm_opt.cu 2>build.err
    }

    if try_build; then
        pass "编译 + 链接成功（extern \"C\" void solve 的符号名与签名对得上）"
    elif grep -qi "unsupported GNU version\|unsupported compiler" build.err; then
        EXTRA="-allow-unsupported-compiler"
        echo "  gcc 版本高于该 CUDA 的支持范围，加 $EXTRA 重试"
        if try_build; then
            pass "编译 + 链接成功（已加 $EXTRA）"
        else
            fail "编译失败"
            sed -n '1,20p' build.err | sed 's/^/    /'
        fi
    elif grep -qi "Unsupported gpu architecture" build.err && [ -n "$ARCH" ]; then
        echo "  该 CUDA 版本不认 $ARCH，改为不指定架构重试"
        ARCH=""
        if try_build; then
            pass "编译 + 链接成功（未指定架构）"
        else
            fail "编译失败"
            sed -n '1,20p' build.err | sed 's/^/    /'
        fi
    else
        fail "编译失败"
        sed -n '1,20p' build.err | sed 's/^/    /'
    fi

    if [ -x ./test_gemm ]; then
        echo
        echo "  --- 资源用量（平台上限：shared 48 KiB）---"
        # shellcheck disable=SC2086
        nvcc -O3 -std=c++14 $EXTRA $ARCH -Xptxas -v -c gemm_opt.cu -o /dev/null 2>&1 \
            | grep -iE "Used .*registers|spill" | sed 's/^/  /' \
            || echo "  （未取到 ptxas 输出）"
        echo
        echo "  --- 端到端 16 组尺寸 ---"
        # shellcheck disable=SC2086
        ./test_gemm
        rc=$?
        case "$rc" in
            0) pass "16 组尺寸全部 PASS" ;;
            2) echo "  [SKIP] 本机无可用 GPU，端到端未执行（不算失败）" ;;
            1) fail "存在 FAIL 用例（真问题，见上面的误差列）" ;;
            *) fail "运行期出错，退出码 $rc" ;;
        esac
    fi
    rm -f build.err
fi
echo

# ------------------------------------------------------- 3. 文件指纹 --------
echo "===== 3) 文件指纹（确认拿到的文件没被改动）====="
if command -v sha256sum >/dev/null 2>&1; then
    sha256sum -c MANIFEST.txt 2>&1 | sed 's/^/  /'
else
    echo "  跳过：没有 sha256sum"
fi
echo

# ------------------------------------------------------- 结论 ---------------
echo "============================================================"
echo " 通过 $ok 项，未通过 $bad 项"
if [ "$bad" -eq 0 ]; then
    if [ "$HAS_GPU" -eq 1 ] && [ "$HAS_NVCC" -eq 1 ]; then
        echo " 结论：CPU 逻辑对拍 + GPU 端到端全部通过。"
    else
        echo " 结论：CPU 侧逻辑对拍通过；本机缺 CUDA/GPU，端到端未执行。"
        echo "       正确性结论以第 1 项为准（等价语义，逐位对拍）。"
    fi
else
    echo " 结论：有未通过项，见上面的 [FAIL]。"
fi
echo "============================================================"
[ "$bad" -eq 0 ] && exit 0 || exit 1
